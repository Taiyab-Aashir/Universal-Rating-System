create trigger book_check2
  after UPDATE
  on bookrating
  for each row
  update polls_bookitem set book_rating = (book_rating + (select sum(rating) from bookrating where bookid=new.bookid) ) / (1 + (select count(*) from bookrating where bookid=NEW.bookid)) where polls_bookitem.id=NEW.bookid;

