create trigger movie_check2
  after UPDATE
  on movierating
  for each row
  update polls_movieitem set movie_rating = (movie_rating + (select sum(rating) from movierating where movieid=new.movieid) ) / (1 + (select count(*) from movierating where movieid=NEW.movieid)) where polls_movieitem.id=NEW.movieid;

