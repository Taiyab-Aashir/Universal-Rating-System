create trigger game_check
  after INSERT
  on gamerating
  for each row
  update polls_gameitem set game_rating = (game_rating + (select sum(rating) from gamerating where gameid=new.gameid) ) / (1 + (select count(*) from gamerating where gameid=NEW.gameid)) where polls_gameitem.id=NEW.gameid;

